package com.naresh.Blended_Siksha_learning;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
