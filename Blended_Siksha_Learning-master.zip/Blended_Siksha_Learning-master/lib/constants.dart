import 'package:flutter/material.dart';

class Constant {
  static final Color primaryColor = Colors.orangeAccent[700];
  static final Color secondaryColor = Colors.grey;
}
class Images {
  static final AssetImage app_logo = AssetImage('assets/image/app_logo.jpg');
}

  class NetworkConstant {}
