class NeetUploadedCoursesModel {
  final String img;
  final String subject;
  final String openPageName;

  NeetUploadedCoursesModel({this.img, this.subject, this.openPageName});
}
