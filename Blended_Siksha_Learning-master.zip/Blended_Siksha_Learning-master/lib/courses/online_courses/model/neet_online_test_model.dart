class NeetOnlineTestModel {
  final String img;
  final String subject;
  final String openPageName;

  NeetOnlineTestModel({this.img, this.subject, this.openPageName});
}
