class NeetJeeMathModel {
  final String img;
  final String details;
  final String editor;
  final String amount;
  final String totalAmount;

  NeetJeeMathModel(
      {this.img, this.details, this.editor, this.amount, this.totalAmount});
}
