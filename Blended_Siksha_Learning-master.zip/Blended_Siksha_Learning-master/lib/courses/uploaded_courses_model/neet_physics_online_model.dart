import 'package:flutter/material.dart';

class NeetPhysicsOnlineModel {
  final String totalQue;
  final String onlineTest;
  final String mistake;
  final String totalMistake;
  final IconData icon;

  NeetPhysicsOnlineModel(
      {this.totalQue,
      this.onlineTest,
      this.mistake,
      this.totalMistake,
      this.icon});
}
