class NeetRecentlyStartedModel {
  final String img;
  final String title;
  final String subtitle;
  final String time;
  NeetRecentlyStartedModel({this.img, this.title, this.subtitle, this.time});
}
