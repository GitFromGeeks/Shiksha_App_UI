import 'package:flutter/material.dart';

class QuestionBankModel {
  final String que;
  final String totalQue;
  final IconData icon;

  QuestionBankModel({this.que, this.totalQue, this.icon});
}
