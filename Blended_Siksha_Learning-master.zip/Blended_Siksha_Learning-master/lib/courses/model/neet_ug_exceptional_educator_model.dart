class NeetExceptionalEducatorsModel {
  final String img;
  final String name;
  final String subject;
  NeetExceptionalEducatorsModel({this.img, this.name, this.subject});
}
