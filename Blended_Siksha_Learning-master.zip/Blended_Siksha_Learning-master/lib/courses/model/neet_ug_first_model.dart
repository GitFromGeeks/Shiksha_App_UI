class NeetUgFirstModel {
  final String img;
  final String name;
  NeetUgFirstModel({this.img, this.name});
}
