class NeetQuestionBankModel {
  final String img;
  NeetQuestionBankModel({this.img});
}
