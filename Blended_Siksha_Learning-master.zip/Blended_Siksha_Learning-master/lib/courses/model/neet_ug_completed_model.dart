class NeetCompletedModel {
  final String img;
  final String title;
  final String subtitle;
  final String time;
  NeetCompletedModel({this.img, this.title, this.subtitle, this.time});
}
