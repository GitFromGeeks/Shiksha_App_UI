class NeetAllSubjectModel {
  final String img;
  final String title;
  final String subtitle;
  final String time;
  NeetAllSubjectModel({this.img, this.title, this.subtitle, this.time});
}
